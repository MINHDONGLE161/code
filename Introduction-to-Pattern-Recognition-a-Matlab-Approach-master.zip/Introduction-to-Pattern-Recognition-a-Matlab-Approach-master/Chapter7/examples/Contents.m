% "Introduction to Pattern Recognition: A MATLAB Approach"
% S. Theodoridis, A. Pikrakis, K. Koutroumbas, D. Cavouras
%
% CHAPTER 3: book examples
%
%   example741 - Example 7.4.1
%   example742 - Example 7.4.2
%   example751 - Example 7.5.1
%   example752 - Example 7.5.2
%   example753 - Example 7.5.3
%   example754 - Example 7.5.4
%   example755 - Example 7.5.5
%   example756 - Example 7.5.6
%   example757 - Example 7.5.7
%   example761 - Example 7.6.1
%   example762 - Example 7.6.2
%   example772 - Example 7.7.2
