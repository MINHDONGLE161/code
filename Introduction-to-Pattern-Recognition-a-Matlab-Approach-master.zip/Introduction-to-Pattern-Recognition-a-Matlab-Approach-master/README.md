Software for the book:
“Introduction to Pattern Recognition: a MATLAB Approach”,
Sergios Theodoridis, Aggelos Pikrakis, Konstantinos Koutroumbas, Dionisis Cavouras
Academic Press (imprint of Elsevier Science), 2010
